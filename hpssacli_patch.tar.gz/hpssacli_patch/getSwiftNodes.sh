#!/bin/bash
sudo su -
source /root/stackrc
nova list | grep SwiftStorage | awk '{print $12}' | sed 's/ctlplane=//'
