#!/bin/bash

source /root/stackrc
SEED="$(nova list | grep undercloud | awk '{print $12}' | sed 's/ctlplane=//')"

SWIFT="$(ssh heat-admin@$SEED 'bash -s' < getSwiftNodes.sh)"

for i in $SWIFT; do
            scp hpssacli-2.0-16.0_amd64.deb heat-admin@$i:/home/heat-admin
	    # remove first if there are leftover installation of hpssacli
	    ssh heat-admin@$i "sudo dpkg -r hpssacli"
            ssh heat-admin@$i "sudo dpkg -i hpssacli-2.0-16.0_amd64.deb"
done

